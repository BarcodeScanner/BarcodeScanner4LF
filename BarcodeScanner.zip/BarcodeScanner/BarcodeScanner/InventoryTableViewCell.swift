import UIKit

class InventoryTableViewCell: UITableViewCell {

    @IBOutlet weak var inventoryName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
}
